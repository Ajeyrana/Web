
<?php
session_start();
$conn = new mysqli("localhost", "root", "", "onlinefood");

if (!isset($_SESSION['last_checked'])) {
    $_SESSION['last_checked'] = date("Y-m-d H:i:s");
}

$last_checked = $_SESSION['last_checked'];
$_SESSION['last_checked'] = date("Y-m-d H:i:s");

$result = $conn->query("SELECT COUNT(*) as new_orders FROM orders WHERE created_at > '$last_checked'");
$data = $result->fetch_assoc();
echo json_encode(['new_order' => $data['new_orders'] > 0]);
?>
