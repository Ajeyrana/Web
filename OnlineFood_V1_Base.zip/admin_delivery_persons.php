
<?php
include 'header.php';
$conn = new mysqli("localhost", "root", "", "onlinefood");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['name']) && !empty($_POST['name'])) {
        $stmt = $conn->prepare("INSERT INTO delivery_persons (name, phone) VALUES (?, ?)");
        $stmt->bind_param("ss", $_POST['name'], $_POST['phone']);
        $stmt->execute();
    }
    if (isset($_GET['delete'])) {
        $id = intval($_GET['delete']);
        $conn->query("DELETE FROM delivery_persons WHERE id = $id");
    }
}

$result = $conn->query("SELECT * FROM delivery_persons");
?>

<div class="container my-5 text-light">
    <h2 class="mb-4">Delivery Personnel</h2>
    <form method="POST" class="row g-3 mb-4">
        <div class="col-md-5">
            <input type="text" name="name" class="form-control bg-dark text-light" placeholder="Delivery Person Name" required>
        </div>
        <div class="col-md-5">
            <input type="text" name="phone" class="form-control bg-dark text-light" placeholder="Phone (optional)">
        </div>
        <div class="col-md-2">
            <button type="submit" class="btn btn-success w-100">Add</button>
        </div>
    </form>

    <table class="table table-dark table-bordered">
        <thead>
            <tr>
                <th>#</th>
                <th>Name</th>
                <th>Phone</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = $result->fetch_assoc()): ?>
            <tr>
                <td><?php echo $row['id']; ?></td>
                <td><?php echo htmlspecialchars($row['name']); ?></td>
                <td><?php echo htmlspecialchars($row['phone']); ?></td>
                <td>
                    <a href="?delete=<?php echo $row['id']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('Delete this person?')">Delete</a>
                </td>
            </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</div>

<?php include 'footer.php'; ?>
