
<?php
include 'header.php';
$conn = new mysqli("localhost", "root", "", "onlinefood");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Update GST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $gst = floatval($_POST["gst_percent"]);
    $check = $conn->query("SELECT id FROM gst_settings LIMIT 1");
    if ($check->num_rows > 0) {
        $conn->query("UPDATE gst_settings SET gst_percent = $gst");
    } else {
        $conn->query("INSERT INTO gst_settings (gst_percent) VALUES ($gst)");
    }
}

// Get current GST
$result = $conn->query("SELECT gst_percent FROM gst_settings LIMIT 1");
$row = $result->fetch_assoc();
$current_gst = $row ? $row["gst_percent"] : 0;
?>

<div class="container my-5 text-light">
    <h2 class="text-center mb-4">GST Settings</h2>
    <form method="POST" class="bg-dark p-4 rounded shadow w-50 mx-auto">
        <div class="mb-3">
            <label>Current GST Percentage (%)</label>
            <input type="number" name="gst_percent" step="0.01" class="form-control bg-light text-dark" value="<?php echo $current_gst; ?>" required>
        </div>
        <button type="submit" class="btn btn-success w-100">Update GST</button>
    </form>
</div>
<?php include 'footer.php'; ?>
