
<?php
include 'header.php';
$conn = new mysqli("localhost", "root", "", "onlinefood");

$search = $_GET['search'] ?? '';
$category = $_GET['category'] ?? '';
$page = max(1, intval($_GET['page'] ?? 1));
$limit = 10;
$offset = ($page - 1) * $limit;

$categories = [];
$cat_result = $conn->query("SELECT * FROM category");
while ($cat = $cat_result->fetch_assoc()) $categories[] = $cat;

$where = "WHERE 1";
if ($search) $where .= " AND name LIKE '%" . $conn->real_escape_string($search) . "%'";
if ($category) $where .= " AND category = '" . $conn->real_escape_string($category) . "'";

$total = $conn->query("SELECT COUNT(*) as total FROM items $where")->fetch_assoc()['total'];
$total_pages = ceil($total / $limit);

$result = $conn->query("SELECT * FROM items $where ORDER BY id DESC LIMIT $limit OFFSET $offset");
?>

<div class="container text-light my-4">
    <h2 class="mb-4">Manage Items</h2>

    <form class="row g-3 mb-4" method="GET">
        <div class="col-md-4">
            <input type="text" name="search" class="form-control bg-dark text-light" placeholder="Search item..." value="<?php echo htmlspecialchars($search); ?>">
        </div>
        <div class="col-md-4">
            <select name="category" class="form-select bg-dark text-light">
                <option value="">All Categories</option>
                <?php foreach ($categories as $cat): ?>
                    <option value="<?php echo $cat['category_name']; ?>" <?php echo $category === $cat['category_name'] ? 'selected' : ''; ?>>
                        <?php echo htmlspecialchars($cat['category_name']); ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="col-md-2">
            <button class="btn btn-primary w-100">Filter</button>
        </div>
    </form>

    <table class="table table-dark table-bordered text-center">
        <thead class="bg-secondary">
            <tr>
                <th>ID</th><th>Name</th><th>Price</th><th>Category</th><th>Image</th><th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($item = $result->fetch_assoc()): ?>
                <tr>
                    <td><?php echo $item['id']; ?></td>
                    <td><?php echo htmlspecialchars($item['name']); ?></td>
                    <td>₹<?php echo $item['price']; ?></td>
                    <td><?php echo htmlspecialchars($item['category']); ?></td>
                    <td><img src="items/<?php echo $item['image']; ?>" height="50"></td>
                    <td>
                        <a href="edit_item.php?id=<?php echo $item['id']; ?>" class="btn btn-sm btn-warning">Edit</a>
                        <a href="delete_item.php?id=<?php echo $item['id']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('Delete this item?');">Delete</a>
                    </td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>

    <nav class="mt-4">
        <ul class="pagination justify-content-center">
            <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                <li class="page-item <?php echo $page == $i ? 'active' : ''; ?>">
                    <a class="page-link bg-dark text-light" href="?page=<?php echo $i; ?>&search=<?php echo urlencode($search); ?>&category=<?php echo urlencode($category); ?>"><?php echo $i; ?></a>
                </li>
            <?php endfor; ?>
        </ul>
    </nav>
</div>

<?php include 'footer.php'; ?>
