
<?php
include 'header.php';
$conn = new mysqli("localhost", "root", "", "onlinefood");

$search = $_GET['search'] ?? '';
$status = $_GET['status'] ?? '';
$page = max(1, intval($_GET['page'] ?? 1));
$limit = 10;
$offset = ($page - 1) * $limit;

$where = "WHERE 1";
if ($search) $where .= " AND order_id LIKE '%" . $conn->real_escape_string($search) . "%'";
if ($status) $where .= " AND status = '" . $conn->real_escape_string($status) . "'";

$total = $conn->query("SELECT COUNT(*) as total FROM orders $where")->fetch_assoc()['total'];
$total_pages = ceil($total / $limit);

$result = $conn->query("SELECT * FROM orders $where ORDER BY id DESC LIMIT $limit OFFSET $offset");
?>

<div class="container text-light my-4">
    <h2 class="mb-4">Manage Orders</h2>

    <form class="row g-3 mb-4" method="GET">
        <div class="col-md-4">
            <input type="text" name="search" class="form-control bg-dark text-light" placeholder="Search by Order ID..." value="<?php echo htmlspecialchars($search); ?>">
        </div>
        <div class="col-md-4">
            <select name="status" class="form-select bg-dark text-light">
                <option value="">All Status</option>
                <option value="pending" <?php if ($status == 'pending') echo 'selected'; ?>>Pending</option>
                <option value="preparing" <?php if ($status == 'preparing') echo 'selected'; ?>>Preparing</option>
                <option value="ready" <?php if ($status == 'ready') echo 'selected'; ?>>Ready</option>
                <option value="out for delivery" <?php if ($status == 'out for delivery') echo 'selected'; ?>>Out for Delivery</option>
                <option value="delivered" <?php if ($status == 'delivered') echo 'selected'; ?>>Delivered</option>
            </select>
        </div>
        <div class="col-md-2">
            <button class="btn btn-primary w-100">Filter</button>
        </div>
    </form>

    <table class="table table-dark table-bordered text-center">
        <thead class="bg-secondary">
            <tr>
                <th>Order ID</th><th>Customer</th><th>Total</th><th>Status</th><th>Date</th><th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($order = $result->fetch_assoc()): ?>
                <tr>
                    <td><?php echo $order['order_id']; ?></td>
                    <td><?php echo htmlspecialchars($order['customer_name']); ?></td>
                    <td>₹<?php echo $order['total_amount']; ?></td>
                    <td><?php echo ucfirst($order['status']); ?></td>
                    <td><?php echo $order['order_date']; ?></td>
                    <td>
                        <a href="view_order.php?id=<?php echo $order['id']; ?>" class="btn btn-sm btn-info">View</a>
                    </td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>

    <nav class="mt-4">
        <ul class="pagination justify-content-center">
            <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                <li class="page-item <?php echo $page == $i ? 'active' : ''; ?>">
                    <a class="page-link bg-dark text-light" href="?page=<?php echo $i; ?>&search=<?php echo urlencode($search); ?>&status=<?php echo urlencode($status); ?>"><?php echo $i; ?></a>
                </li>
            <?php endfor; ?>
        </ul>
    </nav>
</div>

<?php include 'footer.php'; ?>
