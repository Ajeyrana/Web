
<?php
include 'header.php';
$conn = new mysqli("localhost", "root", "", "onlinefood");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $code = strtoupper(trim($_POST["code"]));
    $type = $_POST["discount_type"];
    $value = $_POST["discount_value"];
    $min = $_POST["min_order_amount"];
    $expires = $_POST["expires_at"];
    $limit = $_POST["usage_limit"];

    $stmt = $conn->prepare("INSERT INTO promo_codes (code, discount_type, discount_value, min_order_amount, expires_at, usage_limit)
                            VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssddsi", $code, $type, $value, $min, $expires, $limit);
    $stmt->execute();
}

// Fetch promo codes
$result = $conn->query("SELECT * FROM promo_codes ORDER BY id DESC");
?>

<div class="container my-5 text-light">
    <h2 class="mb-4 text-center">Manage Promo Codes</h2>
    <form method="POST" class="bg-dark p-4 rounded shadow mb-5">
        <div class="row g-3">
            <div class="col-md-4">
                <label>Promo Code</label>
                <input type="text" name="code" class="form-control bg-light text-dark" required>
            </div>
            <div class="col-md-4">
                <label>Discount Type</label>
                <select name="discount_type" class="form-select bg-light text-dark">
                    <option value="fixed">Fixed (₹)</option>
                    <option value="percent">Percent (%)</option>
                </select>
            </div>
            <div class="col-md-4">
                <label>Discount Value</label>
                <input type="number" step="0.01" name="discount_value" class="form-control bg-light text-dark" required>
            </div>
            <div class="col-md-4">
                <label>Min Order Amount</label>
                <input type="number" step="0.01" name="min_order_amount" class="form-control bg-light text-dark">
            </div>
            <div class="col-md-4">
                <label>Expiration Date</label>
                <input type="datetime-local" name="expires_at" class="form-control bg-light text-dark" required>
            </div>
            <div class="col-md-4">
                <label>Usage Limit</label>
                <input type="number" name="usage_limit" class="form-control bg-light text-dark">
            </div>
        </div>
        <button type="submit" class="btn btn-success mt-4 w-100">Create Promo Code</button>
    </form>

    <h4 class="mb-3">Existing Promo Codes</h4>
    <div class="table-responsive">
        <table class="table table-dark table-bordered">
            <thead>
                <tr>
                    <th>Code</th>
                    <th>Type</th>
                    <th>Value</th>
                    <th>Min Order</th>
                    <th>Expires</th>
                    <th>Used</th>
                    <th>Limit</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = $result->fetch_assoc()): ?>
                <tr>
                    <td><?php echo htmlspecialchars($row["code"]); ?></td>
                    <td><?php echo $row["discount_type"]; ?></td>
                    <td><?php echo $row["discount_value"]; ?></td>
                    <td><?php echo $row["min_order_amount"]; ?></td>
                    <td><?php echo $row["expires_at"]; ?></td>
                    <td><?php echo $row["used_count"]; ?></td>
                    <td><?php echo $row["usage_limit"] ?? "Unlimited"; ?></td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</div>
<?php include 'footer.php'; ?>
