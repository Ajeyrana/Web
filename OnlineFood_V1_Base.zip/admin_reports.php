
<?php
$conn = new mysqli("localhost", "root", "", "onlinefood");
$filter = $_GET['filter'] ?? 'daily';

$condition = "DATE(created_at) = CURDATE()";
if ($filter == "weekly") $condition = "YEARWEEK(created_at) = YEARWEEK(CURDATE())";
elseif ($filter == "monthly") $condition = "MONTH(created_at) = MONTH(CURDATE()) AND YEAR(created_at) = YEAR(CURDATE())";
elseif ($filter == "yearly") $condition = "YEAR(created_at) = YEAR(CURDATE())";

$result = $conn->query("SELECT * FROM orders WHERE $condition ORDER BY created_at DESC");

if (isset($_POST['export']) && $result->num_rows > 0) {
    $filename = "sales_report_" . $filter . "_" . $_POST['export'] . "." . ($_POST['export'] === 'pdf' ? 'pdf' : ($_POST['export'] === 'csv' ? 'csv' : 'xls'));
    header("Content-Disposition: attachment; filename=$filename");
    header("Content-Type: application/vnd.ms-excel");

    echo "Order ID\tCustomer Name\tPhone\tDate\tTotal (with GST)\tCoupon\tInstructions\tDelivery Person\n";
    while ($row = $result->fetch_assoc()) {
        echo "{$row['order_id']}\t{$row['customer_name']}\t{$row['customer_phone']}\t{$row['created_at']}\t{$row['total_amount']}\t{$row['coupon_code']}\t{$row['instructions']}\t{$row['delivery_person']}\n";
    }
    exit;
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Sales Report</title>
    <style>
        body { background: #121212; color: #fff; font-family: Arial; padding: 20px; }
        .container { max-width: 95%; margin: auto; background: #1e1e1e; padding: 20px; border-radius: 10px; }
        select, button { padding: 8px; margin: 10px 0; background: #333; color: #fff; border: none; border-radius: 5px; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { border: 1px solid #444; padding: 8px; text-align: center; }
        th { background: #333; }
    </style>
</head>
<body>
    <div class="container">
        <h2>Sales Report (<?php echo ucfirst($filter); ?>)</h2>
        <form method="get">
            <label>Filter:</label>
            <select name="filter" onchange="this.form.submit()">
                <option value="daily" <?php if($filter=='daily') echo 'selected'; ?>>Today</option>
                <option value="weekly" <?php if($filter=='weekly') echo 'selected'; ?>>This Week</option>
                <option value="monthly" <?php if($filter=='monthly') echo 'selected'; ?>>This Month</option>
                <option value="yearly" <?php if($filter=='yearly') echo 'selected'; ?>>This Year</option>
            </select>
        </form>

        <?php if ($result->num_rows > 0): ?>
        <form method="post">
            <button name="export" value="xls">Export to Excel</button>
            <button name="export" value="csv">Export to CSV</button>
            <button name="export" value="pdf">Export to PDF</button>
        </form>
        <table>
            <thead>
                <tr><th>Order ID</th><th>Customer</th><th>Phone</th><th>Date</th><th>Total (GST)</th><th>Coupon</th><th>Instructions</th><th>Delivery Person</th></tr>
            </thead>
            <tbody>
                <?php while($row = $result->fetch_assoc()): ?>
                <tr>
                    <td><?php echo $row['order_id']; ?></td>
                    <td><?php echo $row['customer_name']; ?></td>
                    <td><?php echo $row['customer_phone']; ?></td>
                    <td><?php echo $row['created_at']; ?></td>
                    <td>₹<?php echo $row['total_amount']; ?></td>
                    <td><?php echo $row['coupon_code'] ?: 'N/A'; ?></td>
                    <td><?php echo $row['instructions'] ?: 'N/A'; ?></td>
                    <td><?php echo $row['delivery_person'] ?: 'N/A'; ?></td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
        <?php else: ?>
            <p>No orders found for selected filter.</p>
        <?php endif; ?>
    </div>
</body>
</html>
