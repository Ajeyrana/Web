
<?php
// Export logic
if (isset($_POST['export']) && $order) {
    $filename = "order_" . $order['order_id'] . "_" . $_POST['export'] . "." . ($_POST['export'] === 'pdf' ? 'pdf' : ($_POST['export'] === 'csv' ? 'csv' : 'xls'));
    header("Content-Disposition: attachment; filename=$filename");
    header("Content-Type: application/vnd.ms-excel");

    echo "Order ID\tCustomer Name\tPhone\tDate\tTotal (with GST)\tCoupon\tInstructions\tDelivery Person\n";
    echo "{$order['order_id']}\t{$order['customer_name']}\t{$order['customer_phone']}\t{$order['created_at']}\t{$order['total_amount']}\t{$order['coupon_code']}\t{$order['instructions']}\t{$order['delivery_person']}\n";
    exit;
}
?>
<?php
$conn = new mysqli("localhost", "root", "", "onlinefood");
$order = null;

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $search_id = $conn->real_escape_string($_POST['order_id']);
    $order = $conn->query("SELECT * FROM orders WHERE order_id = '$search_id'")->fetch_assoc();
    $items = $conn->query("SELECT * FROM order_items WHERE order_id = '$search_id'");
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Search Order</title>
    <style>
        body { background: #121212; color: #f1f1f1; font-family: Arial; padding: 20px; }
        .container { max-width: 600px; margin: auto; background: #1e1e1e; padding: 20px; border-radius: 10px; }
        input, button { padding: 10px; width: 100%; margin-top: 10px; background: #333; color: #fff; border: none; border-radius: 5px; }
        table { width: 100%; margin-top: 20px; border-collapse: collapse; }
        th, td { border: 1px solid #444; padding: 8px; text-align: center; }
    </style>
</head>
<body>
    <div class="container">
        <h2>Search Order by Order ID</h2>
        <form method="post">
            <input type="text" name="order_id" placeholder="Enter Order ID (e.g., ZP0001)" required>
            <button type="submit">Search</button>
        </form>

        <?php if ($order): ?>
            <div style="margin-top: 20px;">
                <h3>Order Details</h3>
                <p><strong>Order ID:</strong> <?php echo $order['order_id']; ?></p>
                <p><strong>Customer:</strong> <?php echo $order['customer_name']; ?></p>
                <p><strong>Phone:</strong> <?php echo $order['customer_phone']; ?></p>
                <p><strong>Total:</strong> ₹<?php echo $order['total_amount']; ?></p>
                <p><strong>Status:</strong> <?php echo ucfirst($order['status']); ?></p>
<p><strong>Delivery Person:</strong> <?php echo $order['delivery_person'] ?? "N/A"; ?></p>
                <table>
                    <thead>
                        <tr><th>Item</th><th>Qty</th><th>Price</th><th>Total</th></tr>
                    </thead>
                    <tbody>
                        <?php while ($item = $items->fetch_assoc()): ?>
                            <tr>
                                <td><?php echo $item['item_name']; ?></td>
                                <td><?php echo $item['quantity']; ?></td>
                                <td>₹<?php echo $item['price']; ?></td>
                                <td>₹<?php echo $item['price'] * $item['quantity']; ?></td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>

<form method="post" style="margin-top: 15px;">
    <label style="display: block; margin-bottom: 5px;">Export as:</label>
    <button name="export" value="xls">Export to Excel</button>
    <button name="export" value="csv">Export to CSV</button>
    <button name="export" value="pdf">Export to PDF</button>
</form>

            </div>
        <?php elseif ($_SERVER["REQUEST_METHOD"] == "POST"): ?>
            <p style="color: red; margin-top: 20px;">No order found with that ID.</p>
        <?php endif; ?>
    </div>
</body>
</html>
