
<?php include 'header.php'; ?>
<div class="container my-5">
    <h2 class="text-light mb-4 text-center">Your Cart</h2>
    <div class="table-responsive">
        <table class="table table-dark table-hover text-center">
            <thead>
                <tr>
                    <th>Item</th>
                    <th>Qty</th>
                    <th>Price</th>
                    <th>Subtotal</th>
                    <th>Remove</th>
                </tr>
            </thead>
            <tbody>
                <!-- Sample Cart Row (loop through cart items here) -->
                <tr>
                    <td>Burger</td>
                    <td>2</td>
                    <td>₹100</td>
                    <td>₹200</td>
                    <td><button class="btn btn-danger btn-sm">X</button></td>
                </tr>
            </tbody>
        </table>
    </div>
    <div class="text-end">
        <h4 class="text-light">Total: ₹<span id="cartTotal">200</span></h4>
        <a href="checkout.php" class="btn btn-success">Proceed to Checkout</a>
    </div>
</div>
<?php include 'footer.php'; ?>
