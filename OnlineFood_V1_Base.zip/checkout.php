
<?php
include 'header.php';
$conn = new mysqli("localhost", "root", "", "onlinefood");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Dummy subtotal (replace with real cart total)
$subtotal = 999;
$discount = 0;
$promo_msg = "";

// Get GST percentage
$gst_percent = 0;
$gst_result = $conn->query("SELECT gst_percent FROM gst_settings LIMIT 1");
if ($gst_row = $gst_result->fetch_assoc()) {
    $gst_percent = $gst_row['gst_percent'];
}

// Promo logic
if (isset($_POST['apply_promo'])) {
    $promo_code = strtoupper(trim($_POST['promo_code']));
    $stmt = $conn->prepare("SELECT * FROM promo_codes WHERE code=? AND expires_at > NOW()");
    $stmt->bind_param("s", $promo_code);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($row = $result->fetch_assoc()) {
        if ($row['min_order_amount'] <= $subtotal &&
            ($row['usage_limit'] === null || $row['used_count'] < $row['usage_limit'])) {
            if ($row['discount_type'] == 'fixed') {
                $discount = $row['discount_value'];
            } else {
                $discount = ($row['discount_value'] / 100) * $subtotal;
            }
            $promo_msg = "Promo code applied! Discount: ₹" . number_format($discount, 2);
        } else {
            $promo_msg = "Promo code not valid for this order.";
        }
    } else {
        $promo_msg = "Invalid or expired promo code.";
    }
}

$after_discount = max(0, $subtotal - $discount);
$gst_amount = ($gst_percent / 100) * $after_discount;
$final_total = $after_discount + $gst_amount;
?>

<div class="container my-5">
    <h2 class="text-center text-light mb-4">Checkout</h2>
    <form action="place_order.php" method="POST" class="bg-dark text-light p-4 rounded shadow">
        <div class="mb-3">
            <label>Full Name</label>
            <input type="text" name="fullname" class="form-control bg-light text-dark" required>
        </div>
        <div class="mb-3">
            <label>Address</label>
            <textarea name="address" rows="3" class="form-control bg-light text-dark" required></textarea>
        </div>
        <div class="mb-3">
            <label>Cooking / Delivery Instructions</label>
            <textarea name="instructions" rows="3" class="form-control bg-light text-dark" placeholder="E.g., No spicy, deliver by 8 PM"></textarea>
        </div>

        <div class="mb-3 row">
            <div class="col-md-8">
                <input type="text" name="promo_code" class="form-control bg-light text-dark" placeholder="Enter promo code">
            </div>
            <div class="col-md-4">
                <button name="apply_promo" class="btn btn-info w-100">Apply</button>
            </div>
        </div>

        <?php if ($promo_msg): ?>
            <div class="alert alert-warning"><?php echo $promo_msg; ?></div>
        <?php endif; ?>

        <div class="mb-3">
            <label>Subtotal:</label>
            <strong class="ms-2">₹<?php echo number_format($subtotal, 2); ?></strong><br>
            <label>Discount:</label>
            <strong class="ms-2 text-success">-₹<?php echo number_format($discount, 2); ?></strong><br>
            <label>GST (<?php echo $gst_percent; ?>%):</label>
            <strong class="ms-2 text-warning">+₹<?php echo number_format($gst_amount, 2); ?></strong><br>
            <label>Final Total:</label>
            <strong class="ms-2 text-info">₹<?php echo number_format($final_total, 2); ?></strong>
        </div>

        <input type="hidden" name="final_total" value="<?php echo $final_total; ?>">
        <input type="hidden" name="applied_code" value="<?php echo isset($promo_code) ? $promo_code : ''; ?>">
        <input type="hidden" name="gst_amount" value="<?php echo $gst_amount; ?>">

        <button type="submit" class="btn btn-success w-100">Place Order</button>
    </form>
</div>
<?php include 'footer.php'; ?>
