
<footer class="bg-dark text-center text-white py-4 mt-5">
    <div class="container">
        <p class="mb-0">&copy; <?php echo date('Y'); ?> FoodOrder. All rights reserved.</p>
    </div>
</footer>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
