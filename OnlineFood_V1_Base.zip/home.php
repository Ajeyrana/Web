
<?php
include 'admin/db_connect.php';

// Handle filters
$category_filter = isset($_GET['category']) ? $_GET['category'] : '';
$search_query = isset($_GET['search']) ? $_GET['search'] : '';
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$items_per_page = 6;
$offset = ($page - 1) * $items_per_page;

// Build WHERE clause
$where = " WHERE 1=1 ";
if ($category_filter) {
    $where .= " AND category_id = {$category_filter}";
}
if ($search_query) {
    $search_query_safe = $conn->real_escape_string($search_query);
    $where .= " AND (name LIKE '%{$search_query_safe}%' OR description LIKE '%{$search_query_safe}%')";
}

// Count total items for pagination
$total_result = $conn->query("SELECT COUNT(*) as total FROM product_list $where");
$total_items = $total_result->fetch_assoc()['total'];
$total_pages = ceil($total_items / $items_per_page);

// Fetch paginated results
$items = $conn->query("SELECT * FROM product_list $where ORDER BY name ASC LIMIT $items_per_page OFFSET $offset");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Online Food Ordering</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .item-card { border: 1px solid #ddd; border-radius: 10px; padding: 15px; margin-bottom: 20px; }
        .item-card img { max-width: 100%; height: 200px; object-fit: cover; border-radius: 8px; }
    </style>
</head>
<body>

<div class="container my-5">
    <h1 class="text-center mb-4">Menu</h1>

    <!-- Filter Form -->
    <form method="get" class="row g-3 mb-4">
        <div class="col-md-4">
            <select name="category" class="form-select" onchange="this.form.submit()">
                <option value="">All Categories</option>
                <?php
                $cat_qry = $conn->query("SELECT * FROM category_list ORDER BY name ASC");
                while($row = $cat_qry->fetch_assoc()):
                    $selected = $row['id'] == $category_filter ? 'selected' : '';
                    echo "<option value='{$row['id']}' $selected>{$row['name']}</option>";
                endwhile;
                ?>
            </select>
        </div>
        <div class="col-md-6">
            <input type="text" name="search" class="form-control" placeholder="Search for items..." value="<?php echo htmlspecialchars($search_query); ?>">
        </div>
        <div class="col-md-2">
            <button type="submit" class="btn btn-primary w-100">Search</button>
        </div>
    </form>

    <!-- Food Items -->
    <div class="row">
        <?php while($item = $items->fetch_assoc()): ?>
            <div class="col-md-4">
                <div class="item-card">
                    <img src="assets/uploads/<?php echo $item['img_path'] ?>" alt="<?php echo $item['name'] ?>">
                    <h5 class="mt-2"><?php echo $item['name'] ?></h5>
                    <p><?php echo $item['description'] ?></p>
                    <p><strong>Price:</strong> ₹<?php echo $item['price'] ?></p>
                </div>
            </div>
        <?php endwhile; ?>
    </div>

    <!-- Pagination -->
    <nav>
        <ul class="pagination justify-content-center mt-4">
            <?php for($i = 1; $i <= $total_pages; $i++): ?>
                <?php
                    $params = $_GET;
                    $params['page'] = $i;
                    $query_string = http_build_query($params);
                ?>
                <li class="page-item <?php echo $i == $page ? 'active' : '' ?>">
                    <a class="page-link" href="?<?php echo $query_string ?>"><?php echo $i ?></a>
                </li>
            <?php endfor; ?>
        </ul>
    </nav>
</div>

</body>
</html>
