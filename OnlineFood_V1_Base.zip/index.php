
<?php include 'header.php'; ?>

<div class="container mt-5">
    <div class="text-center">
        <h1 class="mb-4">Welcome to Our Online Food Ordering System</h1>
        <p class="lead">Delicious food delivered to your doorstep. Browse our menu and place your order now!</p>
        <a href="home.php" class="btn btn-primary btn-lg mt-3">Order Now</a>
    </div>
</div>

<?php include 'footer.php'; ?>
