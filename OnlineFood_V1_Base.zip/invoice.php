
<?php
include 'header.php';
$conn = new mysqli("localhost", "root", "", "onlinefood");

$order_id = $_GET['id'] ?? null;
if (!$order_id) {
    echo "<div class='container text-light my-5'><h4>Invalid Order ID.</h4></div>";
    include 'footer.php';
    exit;
}

$stmt = $conn->prepare("SELECT * FROM orders WHERE custom_order_id = ?");
$stmt->bind_param("s", $order_id);
$stmt->execute();
$result = $stmt->get_result();

if (!$result->num_rows) {
    echo "<div class='container text-light my-5'><h4>Order not found.</h4></div>";
    include 'footer.php';
    exit;
}

$order = $result->fetch_assoc();
?>

<div class="container my-5 text-light">
    <h2 class="mb-4">Invoice</h2>
    <p><strong>Order ID:</strong> <?php echo $order['custom_order_id']; ?></p>
    <p><strong>Name:</strong> <?php echo htmlspecialchars($order['fullname']); ?></p>
    <p><strong>Address:</strong> <?php echo htmlspecialchars($order['address']); ?></p>
    <p><strong>Instructions:</strong> <?php echo htmlspecialchars($order['instructions']); ?></p>
    <p><strong>Promo Code:</strong> <?php echo $order['promo_code'] ?: '-'; ?></p>
    <p><strong>GST:</strong> ₹<?php echo number_format($order['gst_amount'], 2); ?></p>
    <p><strong>Total:</strong> ₹<?php echo number_format($order['total'], 2); ?></p>
    <p><strong>Date:</strong> <?php echo $order['created_at']; ?></p>
</div>

<?php include 'footer.php'; ?>
