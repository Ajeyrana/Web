
<?php
require 'vendor/autoload.php'; // for QR code library
use Endroid\QrCode\QrCode;
use Endroid\QrCode\Writer\PngWriter;

$conn = new mysqli("localhost", "root", "", "onlinefood");
$order_id = $_GET['id'] ?? '';
if (!$order_id) die("Invalid Order ID");

$stmt = $conn->prepare("SELECT * FROM orders WHERE custom_order_id = ?");
$stmt->bind_param("s", $order_id);
$stmt->execute();
$result = $stmt->get_result();
if (!$result->num_rows) die("Order not found");
$order = $result->fetch_assoc();

// Generate QR code
$qr = new QrCode($order['custom_order_id']);
$writer = new PngWriter();
$qr_image = base64_encode($writer->write($qr)->getString());
?>
<!DOCTYPE html>
<html>
<head>
    <title>KOT Slip - <?php echo $order_id; ?></title>
    <style>
        body { font-family: monospace; background: #fff; color: #000; }
        .kot-box { max-width: 400px; margin: 20px auto; padding: 20px; border: 1px dashed #000; }
        .qr img { width: 100px; }
    </style>
</head>
<body>
<div class="kot-box">
    <h2>KOT Slip</h2>
    <p><strong>Order ID:</strong> <?php echo $order['custom_order_id']; ?></p>
    <p><strong>Name:</strong> <?php echo htmlspecialchars($order['fullname']); ?></p>
    <p><strong>Address:</strong> <?php echo htmlspecialchars($order['address']); ?></p>
    <p><strong>Instructions:</strong> <?php echo htmlspecialchars($order['instructions']); ?></p>
    <p><strong>Status:</strong> <?php echo ucfirst(str_replace('_', ' ', $order['status'])); ?></p>
    <div class="qr">
        <img src="data:image/png;base64,<?php echo $qr_image; ?>" alt="QR Code">
    </div>
</div>
<script>window.print();</script>
</body>
</html>
