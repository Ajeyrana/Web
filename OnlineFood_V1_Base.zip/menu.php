
<?php
include 'header.php';
$conn = new mysqli("localhost", "root", "", "onlinefood");

$search = $_GET['search'] ?? '';
$category = $_GET['category'] ?? '';
$page = max(1, intval($_GET['page'] ?? 1));
$limit = 8;
$offset = ($page - 1) * $limit;

// Get categories
$cat_result = $conn->query("SELECT * FROM category");
$categories = [];
while ($c = $cat_result->fetch_assoc()) $categories[] = $c;

// Filtered query
$where = "WHERE 1";
if ($search) $where .= " AND name LIKE '%" . $conn->real_escape_string($search) . "%'";
if ($category) $where .= " AND category = '" . $conn->real_escape_string($category) . "'";

$total_result = $conn->query("SELECT COUNT(*) as total FROM items $where")->fetch_assoc();
$total_pages = ceil($total_result['total'] / $limit);

$query = "SELECT * FROM items $where ORDER BY id DESC LIMIT $limit OFFSET $offset";
$result = $conn->query($query);
?>

<div class="container text-light my-4">
    <h2 class="mb-4 text-center">Our Menu</h2>

    <form class="row g-3 mb-4" method="GET">
        <div class="col-md-4">
            <input type="text" name="search" class="form-control bg-dark text-light" placeholder="Search item..." value="<?php echo htmlspecialchars($search); ?>">
        </div>
        <div class="col-md-4">
            <select name="category" class="form-select bg-dark text-light">
                <option value="">All Categories</option>
                <?php foreach ($categories as $cat): ?>
                    <option value="<?php echo $cat['category_name']; ?>" <?php echo $category === $cat['category_name'] ? 'selected' : ''; ?>>
                        <?php echo htmlspecialchars($cat['category_name']); ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="col-md-2">
            <button class="btn btn-primary w-100">Filter</button>
        </div>
    </form>

    <div class="row row-cols-1 row-cols-md-4 g-4">
        <?php while ($item = $result->fetch_assoc()): ?>
        <div class="col">
            <div class="card bg-dark text-white h-100 shadow rounded">
                <img src="admin/items/<?php echo $item['image']; ?>" class="card-img-top" alt="<?php echo htmlspecialchars($item['name']); ?>">
                <div class="card-body">
                    <h5 class="card-title"><?php echo htmlspecialchars($item['name']); ?></h5>
                    <p class="card-text">₹<?php echo $item['price']; ?></p>
                    <a href="item.php?id=<?php echo $item['id']; ?>" class="btn btn-outline-light btn-sm">View</a>
                </div>
            </div>
        </div>
        <?php endwhile; ?>
    </div>

    <nav class="mt-5">
        <ul class="pagination justify-content-center">
            <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                <li class="page-item <?php echo $page == $i ? 'active' : ''; ?>">
                    <a class="page-link bg-dark text-light" href="?page=<?php echo $i; ?>&search=<?php echo urlencode($search); ?>&category=<?php echo urlencode($category); ?>"><?php echo $i; ?></a>
                </li>
            <?php endfor; ?>
        </ul>
    </nav>
</div>

<?php include 'footer.php'; ?>
