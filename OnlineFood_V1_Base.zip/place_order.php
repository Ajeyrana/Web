
<?php
include 'header.php';
$conn = new mysqli("localhost", "root", "", "onlinefood");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$fullname = $_POST['fullname'];
$address = $_POST['address'];
$instructions = $_POST['instructions'];
$final_total = $_POST['final_total'];
$applied_code = $_POST['applied_code'] ?? null;
$gst_amount = $_POST['gst_amount'] ?? 0;

// Generate next custom order ID
$getLast = $conn->query("SELECT custom_order_id FROM orders ORDER BY id DESC LIMIT 1");
if ($row = $getLast->fetch_assoc()) {
    $last = intval(substr($row['custom_order_id'], 2));
    $next = $last + 1;
} else {
    $next = 1;
}
$custom_order_id = "ZP" . str_pad($next, 4, "0", STR_PAD_LEFT);

// Insert order
$stmt = $conn->prepare("INSERT INTO orders (custom_order_id, fullname, address, instructions, total, promo_code, gst_amount, created_at)
                        VALUES (?, ?, ?, ?, ?, ?, ?, NOW())");
$stmt->bind_param("ssssdsd", $custom_order_id, $fullname, $address, $instructions, $final_total, $applied_code, $gst_amount);
$stmt->execute();

// Update promo usage count if applicable
if (!empty($applied_code)) {
    $update_stmt = $conn->prepare("UPDATE promo_codes SET used_count = used_count + 1 WHERE code = ?");
    $update_stmt->bind_param("s", $applied_code);
    $update_stmt->execute();
}

echo "<div class='container my-5 text-light'><h3 class='text-success'>Order placed successfully! Your Order ID: <strong>$custom_order_id</strong></h3></div>";
include 'footer.php';
?>
