
<?php
$conn = new mysqli("localhost", "root", "", "onlinefood");
$id = $_GET['id'] ?? 0;
$order = $conn->query("SELECT * FROM orders WHERE id = $id")->fetch_assoc();
$items = $conn->query("SELECT * FROM order_items WHERE order_id = '$order[order_id]'");

$qr = "https://api.qrserver.com/v1/create-qr-code/?size=100x100&data=" . urlencode($order['order_id']);
$gst_percent = $order['gst_percent'] ?? 0;
$subtotal = $order['total_amount'] / (1 + ($gst_percent / 100));
$gst_amount = $order['total_amount'] - $subtotal;
?>
<!DOCTYPE html>
<html>
<head>
    <title>Invoice</title>
    <style>
        body { font-family: Arial, sans-serif; background: #fff; color: #000; padding: 20px; }
        .invoice-box { border: 1px solid #000; padding: 20px; max-width: 600px; margin: auto; }
        .text-center { text-align: center; }
        .text-end { text-align: right; }
        table { width: 100%; border-collapse: collapse; margin-top: 15px; }
        th, td { border: 1px solid #000; padding: 6px; text-align: center; }
        .qr { float: right; }
        .mt-2 { margin-top: 10px; }
        @media print { button { display: none; } }
    </style>
</head>
<body>
<div class="invoice-box">
    <div class="text-center">
        <h2 style="margin: 0; font-weight: bold;">Zaiyaka Punjab</h2>
        <h3 style="margin: 0;">Invoice</h3>
        <img src="<?php echo $qr; ?>" class="qr" alt="QR Code">
    </div>

    <div class="mt-2">
        <strong>Order ID:</strong> <?php echo $order['order_id']; ?><br>
        <strong>Customer:</strong> <?php echo htmlspecialchars($order['customer_name']); ?><br>
        <strong>Phone:</strong> <?php echo $order['customer_phone']; ?><br>
        <strong>Date:</strong> <?php echo $order['order_date']; ?>
    </div>

    <table>
        <thead>
            <tr><th>Item</th><th>Qty</th><th>Price</th><th>Total</th></tr>
        </thead>
        <tbody>
            <?php while ($item = $items->fetch_assoc()): ?>
                <tr>
                    <td><?php echo htmlspecialchars($item['item_name']); ?></td>
                    <td><?php echo $item['quantity']; ?></td>
                    <td>₹<?php echo $item['price']; ?></td>
                    <td>₹<?php echo $item['price'] * $item['quantity']; ?></td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>

    <div class="text-end mt-2">
        <p><strong>Subtotal:</strong> ₹<?php echo number_format($subtotal, 2); ?></p>
        <p><strong>GST (<?php echo $gst_percent; ?>%):</strong> ₹<?php echo number_format($gst_amount, 2); ?></p>
        <p><strong>Total:</strong> ₹<?php echo $order['total_amount']; ?></p>
    </div>

    <div class="text-center mt-2">
        <button onclick="window.print()">Print Invoice</button>
    </div>
</div>
</body>
</html>
