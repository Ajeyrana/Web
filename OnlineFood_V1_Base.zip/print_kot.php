
<?php
$conn = new mysqli("localhost", "root", "", "onlinefood");
$id = $_GET['id'] ?? 0;
$order = $conn->query("SELECT * FROM orders WHERE id = $id")->fetch_assoc();
$items = $conn->query("SELECT * FROM order_items WHERE order_id = '$order[order_id]'");

$qr = "https://api.qrserver.com/v1/create-qr-code/?size=100x100&data=" . urlencode($order['order_id']);
?>
<!DOCTYPE html>
<html>
<head>
    <title>KOT Slip</title>
    <style>
        body { font-family: Arial, sans-serif; background: #fff; color: #000; padding: 20px; }
        .kot-box { border: 1px dashed #000; padding: 20px; max-width: 400px; margin: auto; }
        .text-center { text-align: center; }
        .mt-2 { margin-top: 10px; }
        .mt-4 { margin-top: 20px; }
        table { width: 100%; border-collapse: collapse; margin-top: 10px; }
        th, td { border: 1px solid #000; padding: 6px; text-align: center; }
        .qr { float: right; }
        @media print { button { display: none; } }
    </style>
</head>
<body>
<div class="kot-box">
    <div class="text-center">
        <h2 style="margin: 0; font-weight: bold;">Zaiyaka Punjab</h2><h3 style="margin: 0;">KOT SLIP</h3>
        <strong>Order ID: <?php echo $order['order_id']; ?></strong>
        <div class="mt-2">Customer: <?php echo htmlspecialchars($order['customer_name']); ?></div>
        <div>Date: <?php echo $order['order_date']; ?></div>
        <img src="<?php echo $qr; ?>" class="qr" alt="QR Code">
    </div>
    <table class="mt-4">
        <thead>
            <tr><th>Item</th><th>Qty</th></tr>
        </thead>
        <tbody>
            <?php while ($item = $items->fetch_assoc()): ?>
                <tr>
                    <td><?php echo htmlspecialchars($item['item_name']); ?></td>
                    <td><?php echo $item['quantity']; ?></td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
    
    <div class="mt-4">
        <p><strong>Subtotal:</strong> ₹<?php echo number_format($order['total_amount'] / (1 + ($order['gst_percent'] ?? 0) / 100), 2); ?></p>
        <p><strong>GST (<?php echo $order['gst_percent'] ?? 0; ?>%):</strong> ₹<?php echo number_format($order['total_amount'] - $order_total, 2); ?></p>
        <p><strong>Total:</strong> ₹<?php echo $order['total_amount']; ?></p>
    </div>
    <div class="text-center mt-4">

        <button onclick="window.print()">Print KOT</button>
    </div>
</div>
</body>
</html>
