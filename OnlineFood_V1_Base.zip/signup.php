
<?php include 'header.php'; ?>
<div class="container d-flex justify-content-center align-items-center" style="min-height: 90vh;">
    <div class="card bg-dark text-light p-4 shadow-lg" style="width: 100%; max-width: 500px;">
        <h3 class="text-center mb-3">Signup</h3>
        <form action="signup_process.php" method="POST">
            <div class="mb-3">
                <label>Name</label>
                <input type="text" name="name" class="form-control bg-light text-dark" required>
            </div>
            <div class="mb-3">
                <label>Email</label>
                <input type="email" name="email" class="form-control bg-light text-dark" required>
            </div>
            <div class="mb-3">
                <label>Password</label>
                <input type="password" name="password" class="form-control bg-light text-dark" required>
            </div>
            <button type="submit" class="btn btn-success w-100">Create Account</button>
            <div class="mt-3 text-center">
                <a href="login.php" class="text-info">Already have an account? Login</a>
            </div>
        </form>
    </div>
</div>
<?php include 'footer.php'; ?>
