
<?php
include 'header.php';
$conn = new mysqli("localhost", "root", "", "onlinefood");

$id = $_GET['id'] ?? 0;
$order = $conn->query("SELECT * FROM orders WHERE id = $id")->fetch_assoc();
$items = $conn->query("SELECT * FROM order_items WHERE order_id = '$order[order_id]'");

// Generate QR code data
$qr_code = "https://api.qrserver.com/v1/create-qr-code/?size=100x100&data=" . urlencode($order['order_id']);
?>

<div class="container text-light my-4">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h3>Order #<?php echo $order['order_id']; ?></h3>
        <img src="<?php echo $qr_code; ?>" alt="QR Code">
    </div>

    <div class="mb-3">
        <strong>Customer:</strong> <?php echo htmlspecialchars($order['customer_name']); ?><br>
        <strong>Phone:</strong> <?php echo $order['customer_phone']; ?><br>
        <strong>Date:</strong> <?php echo $order['order_date']; ?><br>
        <strong>Status:</strong> <?php echo ucfirst($order['status']); ?>
    </div>

    <table class="table table-dark table-bordered text-center">
        <thead class="bg-secondary">
            <tr>
                <th>Item</th><th>Quantity</th><th>Price</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($item = $items->fetch_assoc()): ?>
                <tr>
                    <td><?php echo htmlspecialchars($item['item_name']); ?></td>
                    <td><?php echo $item['quantity']; ?></td>
                    <td>₹<?php echo $item['price']; ?></td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>

    <h5 class="text-end">Total: ₹<?php echo $order['total_amount']; ?></h5>

    <div class="mt-4 d-flex gap-2">
        <button class="btn btn-primary" onclick="window.print()">Print Invoice</button>
        <a href="print_kot.php?id=<?php echo $id; ?>" class="btn btn-secondary">Print KOT</a>
    </div>
</div>

<?php include 'footer.php'; ?>
