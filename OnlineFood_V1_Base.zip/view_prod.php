
<?php include 'header.php'; ?>
<div class="container my-5">
    <div class="card bg-dark text-light p-4 shadow">
        <div class="row">
            <div class="col-md-5">
                <img src="img/sample.jpg" alt="Product Image" class="img-fluid rounded">
            </div>
            <div class="col-md-7">
                <h2>Burger</h2>
                <p>Delicious grilled burger with lettuce, tomato, and cheese.</p>
                <h4>₹100</h4>
                <form action="add_to_cart.php" method="POST" class="mt-3">
                    <input type="hidden" name="product_id" value="1">
                    <div class="mb-3">
                        <label>Quantity</label>
                        <input type="number" name="qty" value="1" min="1" class="form-control bg-light text-dark" required>
                    </div>
                    <button type="submit" class="btn btn-primary">Add to Cart</button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php include 'footer.php'; ?>
